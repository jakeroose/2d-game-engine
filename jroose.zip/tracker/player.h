#ifndef PLAYER__H
#define PLAYER__H
#include <SDL.h>
#include <string>
#include <vector>
#include <cmath>
#include <list>
#include "multisprite.h"
#include "smartSprite.h"

class Player {
public:
  Player(const std::string&);
  Player(const Player&);

  void draw() const { player.draw(); }
  void update(Uint32 ticks);
  const MultiSprite* getPlayer() const { return &player; }
  void attach(SmartSprite* o) { observers.push_back(o); }
  void detach(SmartSprite* o);

  const std::string& getName() const { return player.getName(); }
  int getX() const { return player.getX(); }
  int getY() const { return player.getY(); }
  const Image* getImage() const {
    return player.getImage();
  }
  int getScaledWidth()  const {
    return player.getScaledWidth();
  }
  int getScaledHeight()  const {
    return player.getScaledHeight();
  }
  const SDL_Surface* getSurface() const {
    return player.getSurface();
  }

  const Vector2f& getPosition() const { return player.getPosition(); }

  void right();
  void left();
  void up();
  void down();
  void stop();


private:
  MultiSprite player;
  Vector2f initialVelocity;
  std::list<SmartSprite*> observers;
  int worldWidth;
  int worldHeight;

  Player& operator=(const Player&) = delete;
};
#endif
